create definer = root@localhost view invoicedetails as
select `c`.`name`        AS `Tên khách hàng`,
       `c`.`phone`       AS `Số điện thoại`,
       `c`.`address`     AS `Địa chỉ`,
       `o`.`totalAmount` AS `Tổng tiền`,
       `o`.`orderDate`   AS `Ngày tạo hóa đơn`
from (`quanlybanhang`.`customers` `c` join `quanlybanhang`.`orders` `o` on ((`c`.`customerId` = `o`.`customerId`)));

