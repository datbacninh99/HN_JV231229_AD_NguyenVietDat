create
    definer = root@localhost procedure GetOrdersByCustomerId(IN customerId varchar(4))
BEGIN
    SELECT *
    FROM Orders
    WHERE customerId = customerId;
END;

