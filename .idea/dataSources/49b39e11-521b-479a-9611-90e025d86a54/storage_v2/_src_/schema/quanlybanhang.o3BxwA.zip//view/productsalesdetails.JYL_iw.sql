create definer = root@localhost view productsalesdetails as
select `p`.`name`                      AS `Tên sản phẩm`,
       `p`.`description`               AS `Mô tả`,
       `p`.`price`                     AS `Giá`,
       ifnull(sum(`od`.`quantity`), 0) AS `Tổng số lượng đã bán ra`
from (`quanlybanhang`.`products` `p` left join `quanlybanhang`.`ordersdetails` `od`
      on ((`p`.`productId` = `od`.`productId`)))
group by `p`.`productId`, `p`.`name`, `p`.`description`, `p`.`price`;

