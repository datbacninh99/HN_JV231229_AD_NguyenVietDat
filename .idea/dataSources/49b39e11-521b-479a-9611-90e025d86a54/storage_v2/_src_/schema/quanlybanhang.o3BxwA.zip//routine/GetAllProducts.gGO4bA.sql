create
    definer = root@localhost procedure GetAllProducts()
BEGIN
    SELECT *
    FROM Products;
END;

