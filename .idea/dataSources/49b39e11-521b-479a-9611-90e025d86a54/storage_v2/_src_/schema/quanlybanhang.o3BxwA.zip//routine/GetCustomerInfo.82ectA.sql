create
    definer = root@localhost procedure GetCustomerInfo(IN customerId varchar(4))
BEGIN
    SELECT *
    FROM Customers
    WHERE customerId = customerId;
END;

